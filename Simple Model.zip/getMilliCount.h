#pragma once
#include <cstdlib>
#include <sys/timeb.h>

int getMilliCount();