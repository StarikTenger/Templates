#pragma once


namespace random{
	void start();
	int intRandom(int min, int max);
	double floatRandom(double min, double max, double sign);
}
